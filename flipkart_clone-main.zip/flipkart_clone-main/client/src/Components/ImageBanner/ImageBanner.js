import React from 'react';
import { Grid, Paper } from '@mui/material';
import makeStyles from '@mui/styles';



const ImageBanner = () => {
  
return(

    <div>

    <div id="img-wrapper">
 <div><img src="https://rukminim1.flixcart.com/fk-p-flap/520/280/image/531752c76136eaff.jpg?q=20" /></div>
 <div><img src="https://rukminim1.flixcart.com/fk-p-flap/520/280/image/7195323e65174b7f.jpg?q=20" /></div>
 <div><img src="https://rukminim1.flixcart.com/fk-p-flap/520/280/image/6a143b96667f5abe.jpg?q=20" /></div>

</div>


<div id="img-wrapper">
 <div><img src="https://rukminim1.flixcart.com/fk-p-flap/520/280/image/531752c76136eaff.jpg?q=20" /></div>
 <div><img src="https://rukminim1.flixcart.com/fk-p-flap/520/280/image/7195323e65174b7f.jpg?q=20" /></div>
 <div><img src="https://rukminim1.flixcart.com/fk-p-flap/520/280/image/6a143b96667f5abe.jpg?q=20" /></div>

</div>

<div id="img-wrapper">
 <div><img src="https://rukminim1.flixcart.com/fk-p-flap/520/280/image/531752c76136eaff.jpg?q=20" /></div>
 <div><img src="https://rukminim1.flixcart.com/fk-p-flap/520/280/image/7195323e65174b7f.jpg?q=20" /></div>
 <div><img src="https://rukminim1.flixcart.com/fk-p-flap/520/280/image/6a143b96667f5abe.jpg?q=20" /></div>

</div>
</div>



)
  
}
export  {ImageBanner};
