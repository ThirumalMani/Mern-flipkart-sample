export const ADD_TO_CART_SUCCESS = "addtocartsuccess"
export const  ADD_TO_CART_ERROR = "addtocartfail"
export const REMOVE_FROM_CART = "removefromcart"
