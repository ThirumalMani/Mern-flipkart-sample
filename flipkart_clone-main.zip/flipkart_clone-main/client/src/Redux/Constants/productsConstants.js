export const PRODUCT_SUCCESS_MSG = "productfetchsuccess"
export const PRODUCT_ERROR_MSG = "productfetchfail"